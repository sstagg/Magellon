"""
Rembg code is modified from and copyright of Daniel Gatis,
and can be found here: https://github.com/danielgatis/rembg
"""
