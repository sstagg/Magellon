from .. import external_stable_diffusion_category

auto1111_group = external_stable_diffusion_category.add_node_group("Automatic1111")
