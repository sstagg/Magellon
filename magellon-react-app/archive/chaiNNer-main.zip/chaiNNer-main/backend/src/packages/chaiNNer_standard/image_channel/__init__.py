from .. import image_channel_category

all_group = image_channel_category.add_node_group("All")
transparency_group = image_channel_category.add_node_group("Transparency")
miscellaneous_group = image_channel_category.add_node_group("Miscellaneous")
