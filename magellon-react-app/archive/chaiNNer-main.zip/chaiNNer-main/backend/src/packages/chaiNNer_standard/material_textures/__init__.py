from .. import material_textures_category

normal_map_group = material_textures_category.add_node_group("Normal Map")
conversion_group = material_textures_category.add_node_group("Conversion")
