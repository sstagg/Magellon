from .. import image_dimensions_category

border_group = image_dimensions_category.add_node_group("Border")
crop_group = image_dimensions_category.add_node_group("Crop")
resize_group = image_dimensions_category.add_node_group("Resize")
utility_group = image_dimensions_category.add_node_group("Utility")
