from .. import utility_category

clipboard_group = utility_category.add_node_group("Clipboard")
value_group = utility_category.add_node_group("Value")
math_group = utility_category.add_node_group("Math")
text_group = utility_category.add_node_group("Text")
color_group = utility_category.add_node_group("Color")
random_group = utility_category.add_node_group("Random")
