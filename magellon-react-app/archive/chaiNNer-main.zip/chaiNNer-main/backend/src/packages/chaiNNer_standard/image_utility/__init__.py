from .. import image_utility_category

modification_group = image_utility_category.add_node_group("Modification")
compositing_group = image_utility_category.add_node_group("Compositing")
miscellaneous_group = image_utility_category.add_node_group("Miscellaneous")
