from .. import image_adjustments_category

adjustments_group = image_adjustments_category.add_node_group("Adjustments")
