from .. import ncnn_category

io_group = ncnn_category.add_node_group("Input & Output")
processing_group = ncnn_category.add_node_group("Processing")
utility_group = ncnn_category.add_node_group("Utility")
batch_processing_group = ncnn_category.add_node_group("Batch Processing")
