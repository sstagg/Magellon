from .. import onnx_category

io_group = onnx_category.add_node_group("Input & Output")
processing_group = onnx_category.add_node_group("Processing")
utility_group = onnx_category.add_node_group("Utility")
batch_processing_group = onnx_category.add_node_group("Batch Processing")
