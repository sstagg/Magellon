export const links = {
    kofi: 'https://ko-fi.com/T6T46KTTW',
};
