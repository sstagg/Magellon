// eslint-disable-next-line no-var
declare var startupFile: string | null;
