package main

import (
	"MagellonCli/cmd"
	"MagellonCli/cmd/app"
	"MagellonCli/cmd/development"
	"MagellonCli/cmd/plugins"
	"MagellonCli/core"
	_ "embed"
	"encoding/json"
	"fmt"
	"github.com/nicksnyder/go-i18n/v2/i18n"
	"github.com/pterm/pterm"
	log "github.com/sirupsen/logrus"
	"golang.org/x/text/language"
)

func dummyCodeForInclusion() {
	//this is dummy to force inclusion of plugins package
	plugins.DummyCodeForInclusion()
	development.DummyCodeForInclusion()
	app.DummyCodeForInclusion()
}

func init() {
	core.SetupLogging()
}

//go:embed embed/plugin_project.json
var plugin_init_bytes []byte

//go:embed embed/magellon_plugin.zip
var plugin_project_bytes []byte

//go:embed embed/mysql.zip
var mysql_docker_composer_bytes []byte

//go:embed embed/elk.zip
var elk_docker_composer_bytes []byte

func main() {
	plugins.PluginProjectFileBytes = plugin_project_bytes
	development.MySqlDockerComposeFileBytes = mysql_docker_composer_bytes

	// Customize the DefaultHeader with a cyan background, black text, and a margin of 15.
	//pterm.DefaultHeader.WithFullWidth().Println("Magellon")

	//txt := "Hello Magellon!"
	//pterm.DefaultBigText.WithLetters(
	//	putils.LettersFromStringWithStyle("M", pterm.FgBlue.ToStyle()),
	//	putils.LettersFromStringWithStyle("agellon", pterm.FgGray.ToStyle())).
	//	Render() // Render the big text to the terminal
	//pterm.DefaultBox.Println("Magellon Cli")
	//showHeader(txt)
	//pterm.DefaultBasicText.Println("cryoEm" + pterm.LightMagenta(" the right way! ") + "context.")

	//configLocalization()

	//osType := core.GetOS()
	//fmt.Printf("Operating System: %s\n", osType)
	//commands.SetupRootCommand()
	//commands.Execute()

	//readConfigs()
	//print(string(plugin_project_bytes))

	cmd.Execute()
	//setupFiberWebServer(config.WebPort)
	//core.RunGinWebServer(config.WebPort)

}

func showHeader(txt string) {
	newHeader := pterm.HeaderPrinter{
		TextStyle:       pterm.NewStyle(pterm.FgBlack),
		BackgroundStyle: pterm.NewStyle(pterm.BgRed),
		Margin:          2,
	}

	// Print the custom header using the new HeaderPrinter.

	newHeader.Println(txt)
}

func configLocalization() {

	bundle := i18n.NewBundle(language.English) //1

	//messageEn := i18n.Message{ //1
	//	ID:    "hello",
	//	Other: "Hello!",
	//}
	//messageFr := i18n.Message{ //2
	//	ID:    "hello",
	//	Other: "Bonjour!",
	//}
	//bundle.AddMessages(language.English, &messageEn) //2
	//bundle.AddMessages(language.French, &messageFr)  //3

	bundle.RegisterUnmarshalFunc("json", json.Unmarshal) //5
	bundle.LoadMessageFile("resources/en.json")          //6
	bundle.LoadMessageFile("resources/fr.json")          //7

	localizer := i18n.NewLocalizer(bundle,
		language.English.String(),
		language.French.String())

	localizeConfig := i18n.LocalizeConfig{ //5
		MessageID: "welcome",
	}

	localization, _ := localizer.Localize(&localizeConfig) //6

	fmt.Println(localization)
}

func readConfigs() {
	config, err := core.ReadConfigs()
	if err != nil {
		log.Fatal(err)
	}
	fmt.Printf("Web Port: %d\n", config.WebPort)
}
