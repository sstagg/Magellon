package core

import (
	"runtime"
	"strings"
)

func GetOS() string {
	switch os := runtime.GOOS; strings.ToLower(os) {
	case "windows":
		return "Windows"
	case "darwin":
		return "macOS"
	case "linux":
		return "Linux"
	default:
		return "Unknown"
	}
}
