// zip_helper.go
package core

import (
	"archive/zip"
	"fmt"
	"io"
	"io/ioutil"
	"os"
	"path/filepath"
)

func ExtractZip(targetFolder string, zipFile []byte) {
	//targetFolder := "magellon_ctf_plugin"

	if _, err := os.Stat(targetFolder); os.IsNotExist(err) {
		err := os.Mkdir(targetFolder, 0755)
		if err != nil {
			fmt.Println("Error creating target folder:", err)
			return
		}
	}

	tmpZipPath := filepath.Join(targetFolder, "temp.zip")

	err := WriteTempZipFile(tmpZipPath, zipFile)
	if err != nil {
		fmt.Println("Error writing temporary zip file:", err)
		return
	}

	err = ExtractZipFile(tmpZipPath, targetFolder)
	if err != nil {
		fmt.Println("Error extracting zip file:", err)
		return
	}

	fmt.Println("Extraction complete. Files are in", targetFolder)

	err = Cleanup(tmpZipPath)
	if err != nil {
		fmt.Println("Error cleaning up temporary files:", err)
	}
}
func WriteTempZipFile(filePath string, data []byte) error {
	return ioutil.WriteFile(filePath, data, 0644)
}

func ExtractZipFile(zipPath, targetFolder string) error {
	r, err := zip.OpenReader(zipPath)
	if err != nil {
		return err
	}
	defer r.Close()

	for _, f := range r.File {
		err := ExtractItem(f, targetFolder)
		if err != nil {
			return err
		}
	}

	return nil
}

func ExtractItem(f *zip.File, targetFolder string) error {
	if f.FileInfo().IsDir() {
		// If it's a directory, create the corresponding directory in the target folder
		dirPath := filepath.Join(targetFolder, f.Name)
		os.MkdirAll(dirPath, os.ModePerm)
		return nil
	}

	rc, err := f.Open()
	if err != nil {
		return err
	}
	defer rc.Close()

	dstPath := filepath.Join(targetFolder, f.Name)
	dstFile, err := os.Create(dstPath)
	if err != nil {
		return err
	}
	defer dstFile.Close()

	_, err = io.Copy(dstFile, rc)
	if err != nil {
		return err
	}

	return nil
}

func Cleanup(filePath string) error {
	return os.Remove(filePath)
}
