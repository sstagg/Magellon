package core

import (
	"github.com/spf13/viper"
)

// Config represents the configuration settings
type Config struct {
	WebPort          int `mapstructure:"web_port"`
	DatabaseSettings struct {
		DBDriver   string `mapstructure:"DB_Driver"`
		DBHost     string `mapstructure:"DB_HOST"`
		DBName     string `mapstructure:"DB_NAME"`
		DBPassword string `mapstructure:"DB_PASSWORD"`
		DBPort     int    `mapstructure:"DB_Port"`
		DBUser     string `mapstructure:"DB_USER"`
	} `mapstructure:"database_settings"`
}

func ReadConfigs() (*Config, error) {
	// Set the name of the configuration file (without the extension)
	viper.SetConfigName("config.dev")
	// Set the path to look for the configuration file
	viper.AddConfigPath(".")

	// Read the configuration file
	if err := viper.ReadInConfig(); err != nil {
		return nil, err
	}
	// Create a new Config instance
	var config Config
	// Unmarshal the configuration into the struct
	if err := viper.Unmarshal(&config); err != nil {
		return nil, err
	}

	// Print the values
	//fmt.Printf("Web Port: %d\n", config.WebPort)
	// Uncomment the lines below to print other values
	// fmt.Printf("DB Driver: %s\n", config.DatabaseSettings.DBDriver)
	// fmt.Printf("DB Host: %s\n", config.DatabaseSettings.DBHost)
	// fmt.Printf("DB Name: %s\n", config.DatabaseSettings.DBName)
	// fmt.Printf("DB Password: %s\n", config.DatabaseSettings.DBPassword)
	// fmt.Printf("DB Port: %d\n", config.DatabaseSettings.DBPort)
	// fmt.Printf("DB User: %s\n", config.DatabaseSettings.DBUser)

	return &config, nil
}
