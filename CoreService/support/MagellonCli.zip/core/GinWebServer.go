package core

import (
	"fmt"
	"github.com/gin-gonic/gin"
	log "github.com/sirupsen/logrus"
	"html/template"
	"net/http"
)

const htmlTemplate = `
<!DOCTYPE html>
<html>
<head>
	<title>{{.title}}</title>
</head>
<body>
	<h1>{{.title}}</h1>
</body>
</html>
`

func RunGinWebServer(port int) {
	r := gin.Default()

	// Load HTML template
	r.SetHTMLTemplate(template.Must(template.New("index").Parse(htmlTemplate)))

	// Define a route for the root path
	r.GET("/", func(c *gin.Context) {
		c.HTML(http.StatusOK, "index", gin.H{
			"title": "Hello, Gin!",
		})
	})

	r.GET("/ping", func(c *gin.Context) {
		c.JSON(200, gin.H{
			"message": "pong",
		})
	})
	addr := fmt.Sprintf(":%d", port)
	log.WithFields(log.Fields{"web": "Fiber", "Port": addr}).Warn("Now you can open your browser and go to http://localhost" + addr)
	r.Run(addr) // listen and serve on 0.0.0.0:addr
}
