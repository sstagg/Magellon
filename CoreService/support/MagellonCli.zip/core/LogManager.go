package core

import (
	"github.com/sirupsen/logrus"
	"os"
)

func SetupLogging() {
	logrus.SetOutput(os.Stdout)
	logrus.SetLevel(logrus.InfoLevel)
	logrus.SetFormatter(&logrus.TextFormatter{
		ForceColors:               true,
		DisableColors:             false,
		EnvironmentOverrideColors: true,
	})

	//logrus.WithFields(logrus.Fields{"animal": "walrus", "size": 10}).Warn("Welcome to Magellon Cli!")
}
