package core

//import (
//	"fmt"
//	"github.com/gofiber/fiber/v2"
//	"github.com/mikhail-bigun/fiberlogrus"
//	"github.com/sirupsen/logrus"
//)
//
//func setupFiberWebServer(port int) {
//	app := fiber.New(fiber.Config{
//		JSONEncoder: json.Marshal,
//		JSONDecoder: json.Unmarshal,
//	})
//	app.Use(fiberlogrus.New())
//
//	app.Static("/", "./assets")
//	app.Get("/", func(c *fiber.Ctx) error {
//		return c.SendString("Hello, World!")
//	})
//	app.Get("/hello/:value", func(c *fiber.Ctx) error {
//		return c.SendString("Hello " + c.Params("value"))
//		// => Get request with value: hello world
//	})
//	addr := fmt.Sprintf(":%d", port)
//	logrus.WithFields(logrus.Fields{"web": "Fiber", "Port": addr}).Warn("Now you can open your browser and go to http://localhost:" + addr)
//	if err := app.Listen(addr); err != nil {
//		logrus.WithError(err).Error("Error starting web server")
//	}
//}
