package core

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
)

func RunCommand(dir string, command string, args ...string) (string, error) {
	cmd := exec.Command(command, args...)

	// Uncomment and set the working directory if necessary
	cmd.Dir = dir

	output, err := cmd.CombinedOutput()

	if err != nil {
		return string(output), fmt.Errorf("error running %s: %v", command, err)
	}

	return string(output), nil
}

func GetTargetDirectory(args []string, extraDirs ...string) (string, error) {
	var dirPath string

	// Check if at least one argument is provided
	if len(args) > 0 {
		dirPath = args[0]
	} else {
		// If no argument is provided, set dirPath to the current directory
		currentDir, err := os.Getwd()
		if err != nil {
			return "", fmt.Errorf("Error getting current directory: %v", err)
		}
		dirPath = currentDir
	}

	// Append extra directories to the path
	for _, extraDir := range extraDirs {
		dirPath = filepath.Join(dirPath, extraDir)
	}

	// Print the determined directory path
	fmt.Printf("Target Directory: %s\n", dirPath)

	// Create the directory if it doesn't exist
	if err := os.MkdirAll(dirPath, 0777); err != nil {
		return "", fmt.Errorf("Error creating target directory: %v", err)
	}

	return dirPath, nil
}
