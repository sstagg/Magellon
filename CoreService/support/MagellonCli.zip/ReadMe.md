
### Libraries:
Logrus
go get -u github.com/sirupsen/logrus
go get -u github.com/spf13/cobra@latest
go get -u github.com/spf13/viper
go get -u gorm.io/driver/mysql
go get -u gorm.io/gorm

go get -u github.com/goccy/go-json

go get -u github.com/hashicorp/go-getter
go get -u github.com/cavaliergopher/grab/v3

go get -u github.com/cavaliergopher/grab/v3

$ go get github.com/mholt/archiver/v4


https://lokalise.com/blog/go-internationalization-using-go-i18n/
go get -u github.com/nicksnyder/go-i18n/v2/i18n

go get -u github.com/pterm/pterm

import "github.com/gosuri/uitable"
https://github.com/jedib0t/go-pretty
https://github.com/charmbracelet/lipgloss
https://github.com/pterm/pterm
https://github.com/rivo/tview
https://github.com/charmbracelet/bubbletea
https://pterm.sh/

go get -u github.com/nicksnyder/go-i18n/v2/i18n


go get -u github.com/rivo/tview
go get github.com/cheggaaa/pb/v3

go get -u github.com/gin-gonic/gin


go get fyne.io/fyne/v2@latest


$ go get github.com/mholt/archiver/v4
https://github.com/mcmilk/7-Zip-zstd
#### Logging :
Logrus
https://github.com/highlight/highlight

go get -u github.com/mikhail-bigun/fiberlogrus

#### Web :
Fiber
GIN :  go get -u github.com/gin-gonic/gin
ECHO
https://gofiber.io/
go get -u github.com/gofiber/fiber/v2


### Deployment
go tool dist list
go env GOOS GOARCH

go build -o hello.exe -ldflags "-w -s"
GOOS=linux GOARCH=amd64 go build -o hello.exe -ldflags "-w -s"

`
chmod +x ./magellon
`
### Commands:
magellon install app

magellon development setup
magellon development load

magellon login -u:behdad -p

magellon plugins create init
magellon plugins create myctf
magellon plugins deploy myctf
magellon plugins list -a -s:author
magellon plugins install myctf@latest

plugins create myctf
[index.html](..%2F..%2Fmagellon%2Fweb%2Fhtml%2Findex.html)

gentool -dsn "behdad:behd1d#34@tcp(5.161.212.237:3306)/magellon01?charset=utf8mb4&parseTime=True&loc=Local"

### Articles

https://dev.to/leninkumar35/a-brief-introduction-to-download-managers-in-golang-51oo
https://dev.to/koddr/go-fiber-by-examples-how-can-the-fiber-web-framework-be-useful-487a

cobra-cli add install
go run ./main.go plugins create behdad


### Docker
docker build -t magellon-website .
docker run -p 8080:80 magellon-website

docker tag magellon-website khoshbin/magellon-website:latest

### Run Mac
uname -m
after unzipping
chmod +x ./magellon