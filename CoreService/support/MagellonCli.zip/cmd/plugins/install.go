/*
Copyright © 2023 NAME HERE <EMAIL ADDRESS>
*/
package plugins

import (
	"fmt"
	"github.com/spf13/cobra"
)

// installCmd represents the install command
var installCmd = &cobra.Command{
	Use:   "install",
	Short: "Install your plugin in Magellon",
	Long: `Install command is used to add and activate your plugin within Magellon.
This command facilitates a seamless installation process, ensuring that your plugin is integrated and ready for use.
Use this command to easily enhance Magellon's functionality with your custom plugin features.`,
	Run: func(cmd *cobra.Command, args []string) {
		fmt.Println("Installing your plugin in Magellon...")
		// Additional installation logic can be added here
		fmt.Println("Plugin installation completed successfully.")
	},
}
func init() {
	pluginsCmd.AddCommand(installCmd)

	// Here you will define your flags and configuration settings.

	// Cobra supports Persistent Flags which will work for this command
	// and all subcommands, e.g.:
	// installCmd.PersistentFlags().String("foo", "", "A help for foo")

	// Cobra supports local flags which will only run when this command
	// is called directly, e.g.:
	// installCmd.Flags().BoolP("toggle", "t", false, "Help message for toggle")
}
