/*
Copyright © 2023 NAME HERE <EMAIL ADDRESS>
*/
package plugins

import (
	"MagellonCli/cmd"
	"github.com/spf13/cobra"
)

// pluginsCmd represents the plugins command
var pluginsCmd = &cobra.Command{
	Use:     "plugins",
	Short:   "commands related to plugins",
	Aliases: []string{"plg", "plugin", "plu", "pl"},
	Long: `Tasks related to plugins including:
create : to create a plugin
deploy : When your plugin is ready to be deployed to magellon repository
Install: When `,
	//Run: func(cmd *cobra.Command, args []string) {
	//	fmt.Println("plugins called")
	//},
}

func init() {
	cmd.RootCmd.AddCommand(pluginsCmd)

	// Here you will define your flags and configuration settings.

	// Cobra supports Persistent Flags which will work for this command
	// and all subcommands, e.g.:
	// pluginsCmd.PersistentFlags().String("foo", "", "A help for foo")

	// Cobra supports local flags which will only run when this command
	// is called directly, e.g.:
	// pluginsCmd.Flags().BoolP("toggle", "t", false, "Help message for toggle")
}
