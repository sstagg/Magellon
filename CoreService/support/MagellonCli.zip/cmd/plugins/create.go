/*
Copyright © 2023 NAME HERE <EMAIL ADDRESS>
*/
package plugins

import (
	"MagellonCli/core"
	"MagellonCli/tpl/plugin_tpls"
	_ "embed"
	"encoding/json"
	"fmt"
	"github.com/pterm/pterm"
	"github.com/spf13/cobra"
	"io/ioutil"
	"os"
	"path/filepath"
	"time"
)

func DummyCodeForInclusion() {
	fmt.Println("Initializing additional code...")
	// Add your additional code logic here
}

func CreateDirectory(project plugin_tpls.Project) error {
	// Create the directory path using AbsolutePath and Name
	dirPath := filepath.Join(project.AbsolutePath, project.Name)

	// Create the directory
	err := os.MkdirAll(dirPath, os.ModePerm)
	if err != nil {
		return err
	}

	fmt.Printf("Directory '%s' created successfully.\n", dirPath)
	return nil
}

func createReadmeFile(path string) error {
	content := []byte("This is a README file.")

	file, err := os.Create(path)
	if err != nil {
		return err
	}
	defer file.Close()

	_, err = file.Write(content)
	if err != nil {
		return err
	}

	return nil
}

func createProject(project plugin_tpls.Project) error {

	multi := pterm.DefaultMultiPrinter
	spinner1, _ := pterm.DefaultSpinner.WithWriter(multi.NewWriter()).Start("Spinner 1")
	pb1, _ := pterm.DefaultProgressbar.WithTotal(100).WithWriter(multi.NewWriter()).Start("Main File")
	pb2, _ := pterm.DefaultProgressbar.WithTotal(100).WithWriter(multi.NewWriter()).Start("Requirements")
	for i := 1; i <= 100; i++ {
		pb1.Increment() // Increment progress bar 1 every iteration
		if i%2 == 0 {
			pb2.Add(3) // Add 3 to progress bar 2 every even iteration
		}
		if i%50 == 0 {
			spinner1.Success("Spinner 1 is done!") // Mark spinner 1 as successful every 50th iteration
		}
		time.Sleep(time.Millisecond * 50) // Sleep for 50 milliseconds between each iteration
	}
	multi.Stop()

	// Create the directory
	err := CreateDirectory(project)
	if err != nil {
		return err
	}

	// Create readme.txt file
	projectPath := filepath.Join(project.AbsolutePath, project.Name)
	readmePath := filepath.Join(projectPath, "README.md")
	err = createReadmeFile(readmePath)
	if err != nil {
		return err
	}

	pterm.DefaultParagraph.WithMaxWidth(60).Printf("Project '%s' has been successfully created!\n"+
		"You can find your project files in the directory '%s'.\n"+
		"To get started:\n"+
		"1. Open the '%s' directory in your preferred code editor.\n"+
		"2. Review and ReadMe.md file with your plugin details.\n"+
		"3. Explore the '%s' directory for your project source code.\n"+
		"4. Check the 'README.md' file for instructions on how to quickly get started.\n"+
		"Happy coding!\n",
		project.Name, projectPath, projectPath, projectPath)

	return nil
}

var PluginProjectFileBytes []byte



// createCmd represents the create command
var createCmd = &cobra.Command{
	Use:   "create",
	Short: "Create a new project for a Magellon plugin",
	Long: `This command creates a basic Python project for your Magellon plugin. 
To create this project, you need an init.json file containing basic information about your plugin. 
If you don't have the file, you can create it without passing any arguments. 
Afterwards, you can edit the file and rerun the command to generate a new project for your plugin.
`,
	Run: func(cmd *cobra.Command, args []string) {
		//fmt.Println("create called")
		//for i, arg := range args {
		//	fmt.Printf("  Arg%d: %s\n", i+1, arg)
		//}
		// Search for init.json in the current directory
		// Create an interactive text input with single line input mode

		filePath := "init.json"
		project := getDefaultProject()

		content, isGenerated, err := readOrCreateInitFile(project, filePath)
		if err != nil {
			fmt.Println("Error:", err)
			return
		}

		if isGenerated {
			pterm.DefaultBox.Println("init.json generated")
			helper := "To create a Magellon plugin, we require specific information such as the plugin's name and copyright details. Kindly edit the generated init.json using your preferred editor. Afterward, rerun this command to automatically generate the fundamental structure for your Magellon plugin. Wishing you a delightful programming experience with Magellon!"
			pterm.DefaultParagraph.WithMaxWidth(60).Println(helper)

		} else {
			pterm.Success.Println("init.json was found.")
			// Unmarshal JSON data into MotionCor2 struct
			var theProject plugin_tpls.Project
			err := json.Unmarshal([]byte(content), &theProject)
			if err != nil {
				fmt.Println("Error:", err)
				return
			}

			err = createProject(theProject)
			if err != nil {
				fmt.Println("Error creating project:", err)
				return
			}
			dirPath := filepath.Join(theProject.AbsolutePath, theProject.Name)

			core.ExtractZip(dirPath, PluginProjectFileBytes)

			fmt.Printf("Name: %s\nDeveloper: %s\nCopyright: %s\n", theProject.Name, theProject.Developer, theProject.Copyright)
		}
		// Now 'content' holds the content of init.json or the newly generated content
		//fmt.Println("Content:", content)
	},
}

func getDefaultProject() plugin_tpls.Project {

	return plugin_tpls.Project{
		Name:         "DefaultName",
		Developer:    "Behdad Khoshbin",
		Copyright:    "Copyright © 2024 Magellon",
		AbsolutePath: "/magellon/motioncor2/",
		Legal: plugin_tpls.Legal{
			Name:            "MIT",
			PossibleMatches: []string{"MIT", "Apache", "GPL"},
			Text:            "Magellon MotionCor 2 is licensed under the MIT License.MIT License Text...",
			Header:          "MIT License Header...",
		},
		EndpointName: "execute_motioncor",
		Items: []plugin_tpls.Item{
			{
				Name:        "input_image_path",
				Type:        "string",
				IsOptional:  false,
				Description: "Path to the input image for MotionCor 2 processing.",
			},
			{
				Name:        "output_file_name",
				Type:        "string",
				IsOptional:  false,
				Description: "Name of the output file generated by MotionCor 2.",
			},
		},
	}
}

func readOrCreateInitFile(project plugin_tpls.Project, filePath string) (string, bool, error) {
	// Check if the file exists
	if _, err := os.Stat(filePath); os.IsNotExist(err) {
		// File does not exist, generate content and write to the file

		var projectName string
		textInput := pterm.DefaultInteractiveTextInput.WithMultiLine(false)

		// Show the text input and get the projectName
		projectName, err := textInput.Show("Enter Plugin's Name")
		if err != nil {
			fmt.Println("Error:", err)
		}

		for len(projectName) < 3 {
			pterm.Error.Printfln("Plugin's Name must be at least 3 characters long")

			// Show the text input and get the projectName again
			projectName, err = textInput.Show("Enter Plugin's Name")
			if err != nil {
				fmt.Println("Error:", err)
			}
		}
		selectedOption, _ := pterm.DefaultInteractiveSelect.WithOptions(plugin_tpls.Options).Show("Select Plugin's Type")

		// Display the selected option to the user with a green color for emphasis
		pterm.Info.Printfln("Selected option: %s", pterm.Green(selectedOption))
		// projectName is now available outside the loop
		//pterm.Info.Printfln("Plugin's Name: %s", projectName)
		pterm.Success.Printfln("Plugin's Name: %s", projectName)
		project.Name = projectName
		project.Type = plugin_tpls.PluginType(selectedOption)

		content, _ := plugin_tpls.GenerateInitContent(project)
		err = ioutil.WriteFile(filePath, []byte(content), 0644)
		if err != nil {
			return "", false, err
		}
		return content, true, nil
	}

	// File exists, read its content
	content, err := ioutil.ReadFile(filePath)
	if err != nil {
		return "", false, err
	}

	return string(content), false, nil
}

// Convert slice to JSON array string

func generateFastapi() string {
	// Generate your init.json content here
	return `{
  "name": "MotionCor 2",
  "developer": "Behdad Khoshbin",
  "copyright": "Copyright © 2024 Magellon",
  "absolutePath": "/magellon/motioncor2/",
  "legal": {
    "name": "MIT",
    "possibleMatches": ["MIT", "Apache", "GPL"],
    "text": "Magellon MotionCor 2 is licensed under the MIT License.\n\nMIT License Text...",
    "header": "MIT License Header..."
  },
  "endpointName": "execute_motioncor",
  "items": [
    {
      "name": "input_image_path",
      "type": "string",
      "is_optional": false,
      "description": "Path to the input image for MotionCor 2 processing."
    },
    {
      "name": "output_file_name",
      "type": "string",
      "is_optional": false,
      "description": "Name of the output file generated by MotionCor 2."
    }
  ]
}
`
}

func init() {
	pluginsCmd.AddCommand(createCmd)

	// Here you will define your flags and configuration settings.

	// Cobra supports Persistent Flags which will work for this command
	// and all subcommands, e.g.:
	// createCmd.PersistentFlags().String("foo", "", "A help for foo")

	// Cobra supports local flags which will only run when this command
	// is called directly, e.g.:
	// createCmd.Flags().BoolP("toggle", "t", false, "Help message for toggle")
}
