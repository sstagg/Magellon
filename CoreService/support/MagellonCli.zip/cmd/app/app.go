/*
Copyright © 2023 NAME HERE <EMAIL ADDRESS>
*/
package app

import (
	"MagellonCli/cmd"
	"github.com/spf13/cobra"
)

// appCmd represents the app command
var appCmd = &cobra.Command{
	Use:     "application",
	Short:   "Manage your Magellon application",
	Aliases: []string{"app"},
	Long: `Magellon is a CLI tool for managing applications.
This command provides subcommands to install, uninstall, and update applications.`,
	//Run: func(cmd *cobra.Command, args []string) {
	//	fmt.Println("app called")
	//},
}

func init() {
	cmd.RootCmd.AddCommand(appCmd)

	// Here you will define your flags and configuration settings.

	// Cobra supports Persistent Flags which will work for this command
	// and all subcommands, e.g.:
	// appCmd.PersistentFlags().String("foo", "", "A help for foo")

	// Cobra supports local flags which will only run when this command
	// is called directly, e.g.:
	// appCmd.Flags().BoolP("toggle", "t", false, "Help message for toggle")
}
