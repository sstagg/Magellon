/*
Copyright © 2023 NAME HERE <EMAIL ADDRESS>
*/
package app

import (
	"fmt"

	"github.com/spf13/cobra"
)

// uninstallCmd represents the uninstall command
var uninstallCmd = &cobra.Command{
	Use:   "uninstall",
	Short: "Uninstall a Magellon application",
	Long: `Uninstall command is used to remove the Magellon application from your system.
It facilitates a clean removal process, ensuring all associated components are properly uninstalled.
Use this command when you no longer need Magellon on your system.`,
	Run: func(cmd *cobra.Command, args []string) {
		fmt.Println("Uninstalling Magellon...")
		// Additional uninstallation logic can be added here
		fmt.Println("Magellon uninstallation completed successfully.")
	},
}

func init() {
	appCmd.AddCommand(uninstallCmd)

	// Here you will define your flags and configuration settings.

	// Cobra supports Persistent Flags which will work for this command
	// and all subcommands, e.g.:
	// uninstallCmd.PersistentFlags().String("foo", "", "A help for foo")

	// Cobra supports local flags which will only run when this command
	// is called directly, e.g.:
	// uninstallCmd.Flags().BoolP("toggle", "t", false, "Help message for toggle")
}
