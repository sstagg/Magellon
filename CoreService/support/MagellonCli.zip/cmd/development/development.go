/*
Copyright © 2023 NAME HERE <EMAIL ADDRESS>
*/
package development

import (
	"MagellonCli/cmd"
	"github.com/spf13/cobra"
)

// developmentCmd represents the development command
var developmentCmd = &cobra.Command{
	Use:     "development",
	Short:   "A brief description of your command",
	Aliases: []string{"dev", "dv"},
	Long: `The 'development' command is tailored for developers working on Magellon projects. 
It provides tools for setting up and managing a virtual environment to facilitate seamless 
code development for Magellon. Explore the subcommands to streamline your development 
workflow.

Subcommands:
  - 'development setup': Set up a virtual environment for Magellon development.
  - 'development run': Run Magellon in your development environment.

For example:
  - Run 'development setup' to initialize your Magellon development environment.
  - Execute 'development run' to launch Magellon within the virtual environment.

Make the most of your development experience with Magellon, and leverage these commands 
to enhance your workflow.`,
	//Run: func(cmd *cobra.Command, args []string) {
	//	fmt.Println("development called")
	//},
}

func init() {
	cmd.RootCmd.AddCommand(developmentCmd)

	// Here you will define your flags and configuration settings.

	// Cobra supports Persistent Flags which will work for this command
	// and all subcommands, e.g.:
	// developmentCmd.PersistentFlags().String("foo", "", "A help for foo")

	// Cobra supports local flags which will only run when this command
	// is called directly, e.g.:
	// developmentCmd.Flags().BoolP("toggle", "t", false, "Help message for toggle")
}
