/*
Copyright © 2023 NAME HERE <EMAIL ADDRESS>
*/
package development

import (
	"MagellonCli/core"
	"fmt"
	"os"
	"path/filepath"

	"github.com/spf13/cobra"
)

func DummyCodeForInclusion() {

}

// upCmd represents the run command
var upCmd = &cobra.Command{
	Use:   "up",
	Short: "Start the necessary services and servers for Magellon development",
	Long: `The 'run up' command is used to start the required services and servers for 
Magellon development. This includes initializing your development environment 
and launching essential components needed for a smooth development experience.

Example:
  Run 'magellon development setup' to prepare your development environment.downloading all required components
  then Execute 'magellon development up' to start the necessary services and servers.

Ensure a seamless development process by using this command in conjunction with 
other Magellon development tools.`,
	Run: func(cmd *cobra.Command, args []string) {
		dirPath, err := core.GetTargetDirectory(args, "magellon", "dev")
		if err != nil {
			fmt.Println(err)
			return
		}

		composeFilePath := filepath.Join(dirPath, "docker-compose.yml")
		_, err = os.Stat(composeFilePath)
		if err != nil {
			if os.IsNotExist(err) {
				fmt.Println("Error: docker-compose.yml file not found in the target directory.")
				return
			}
			fmt.Printf("Error checking docker-compose.yml file: %v\n", err)
			return
		}

		output, err := core.RunCommand(dirPath, "docker-compose", "up", "-d")

		if err != nil {
			// Handle the error
			fmt.Printf("Error: %v\n", err)
		} else {
			// Print the output
			fmt.Println("Command output:")
			fmt.Printf("%s\n", output)
		}
	},
}

func init() {
	developmentCmd.AddCommand(upCmd)

	// Here you will define your flags and configuration settings.

	// Cobra supports Persistent Flags which will work for this command
	// and all subcommands, e.g.:
	// upCmd.PersistentFlags().String("foo", "", "A help for foo")

	// Cobra supports local flags which will only run when this command
	// is called directly, e.g.:
	// upCmd.Flags().BoolP("toggle", "t", false, "Help message for toggle")
}
