/*
Copyright © 2023 NAME HERE <EMAIL ADDRESS>
*/
package development

import (
	"MagellonCli/core"
	"fmt"
	"github.com/spf13/cobra"
)

var MySqlDockerComposeFileBytes []byte

// setupCmd represents the setup command
var setupCmd = &cobra.Command{
	Use:   "setup",
	Short: "Initialize the Magellon development environment",
	Long: `The 'development setup' command initializes your Magellon development 
environment. This includes downloading all required components, setting up 
dependencies, and configuring the environment for a seamless development experience.

Example:
  Execute 'magellon development setup' to initialize your development environment.

Ensure a smooth development process by running this command before starting 
other Magellon development tools.`,
	Run: func(cmd *cobra.Command, args []string) {
		//for i, arg := range args {			fmt.Printf("  Arg%d: %s\n", i+1, arg)		}

		dirPath, err := core.GetTargetDirectory(args, "magellon", "dev")
		if err != nil {
			fmt.Println(err)
			return
		}

		core.ExtractZip(dirPath, MySqlDockerComposeFileBytes)

		output, err := core.RunCommand(dirPath, "docker-compose", "up", "-d")

		if err != nil {
			// Handle the error
			fmt.Printf("Error: %v\n", err)
		} else {
			// Print the output
			fmt.Println("Command output:")
			fmt.Printf("%s\n", output)
		}
	},
}

func init() {
	developmentCmd.AddCommand(setupCmd)

	// Here you will define your flags and configuration settings.

	// Cobra supports Persistent Flags which will work for this command
	// and all subcommands, e.g.:
	// setupCmd.PersistentFlags().String("foo", "", "A help for foo")

	// Cobra supports local flags which will only run when this command
	// is called directly, e.g.:
	// setupCmd.Flags().BoolP("toggle", "t", false, "Help message for toggle")
}
