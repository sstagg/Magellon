/*
Copyright © 2023 Behdad Khoshbin b.khoshbin@gmail.com
*/
package cmd

import (
	"fmt"
	"os"

	"github.com/spf13/cobra"
	"github.com/spf13/viper"
)

var cfgFile string

// RootCmd represents the base command when called without any subcommands
var RootCmd = &cobra.Command{
	Use:   "MagellonCli",
	Short: "Magellon CLI - Streamlining Cryo-EM Software Management",
	Long: `Magellon CLI is a powerful command-line interface designed for managing the installation, uninstallation, and upgrading of Magellon, a state-of-the-art Cryo-EM software. This tool also facilitates the setup of a development environment tailored for plugin developers.

Key Features:
- **Installation**: Easily install Magellon with a simple command, ensuring a smooth setup process for users.
- **Uninstallation**: Seamlessly remove Magellon from your system when needed, leaving no traces behind.
- **Upgrade**: Keep Magellon up-to-date by effortlessly upgrading to the latest version, ensuring access to the newest features and improvements.
- **Development Environment Setup**: Magellon CLI provides a streamlined process for setting up a development environment, enabling plugin developers to focus on creating innovative extensions.

Usage Example:
- app install
- app uninstall
- app update
- Setup Development Environment: dev setup

Get started with Magellon CLI and unlock the full potential of Cryo-EM research with enhanced software management and development capabilities.

For more information and detailed usage examples, refer to the official documentation at [documentation-url].`,
	// Uncomment the following line if your bare application
	// has an action associated with it:
	// Run: func(cmd *cobra.Command, args []string) { },
}

// Execute adds all child commands to the root command and sets flags appropriately.
// This is called by main.main(). It only needs to happen once to the RootCmd.
func Execute() {
	err := RootCmd.Execute()
	if err != nil {
		os.Exit(1)
	}
}

func init() {
	cobra.OnInitialize(initConfig)

	// Here you will define your flags and configuration settings.
	// Cobra supports persistent flags, which, if defined here,
	// will be global for your application.

	RootCmd.PersistentFlags().StringVar(&cfgFile, "config", "", "config file (default is $HOME/.MagellonCli.yaml)")

	// Cobra also supports local flags, which will only run
	// when this action is called directly.
	RootCmd.Flags().BoolP("toggle", "t", false, "Help message for toggle")
}

// initConfig reads in config file and ENV variables if set.
func initConfig() {
	if cfgFile != "" {
		// Use config file from the flag.
		viper.SetConfigFile(cfgFile)
	} else {
		// Find home directory.
		home, err := os.UserHomeDir()
		cobra.CheckErr(err)

		// Search config in home directory with name ".MagellonCli" (without extension).
		viper.AddConfigPath(home)
		viper.SetConfigType("yaml")
		viper.SetConfigName(".MagellonCli")
	}

	viper.AutomaticEnv() // read in environment variables that match

	// If a config file is found, read it in.
	if err := viper.ReadInConfig(); err == nil {
		fmt.Fprintln(os.Stderr, "Using config file:", viper.ConfigFileUsed())
	}
}
