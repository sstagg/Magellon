
git clone https://github.com/conduktor/kafka-stack-docker-compose.git
docker-compose -f full-stack.yml up

localhost:8080
admin@admin.io
admin

docker exec -it ksqldb-cli ksql http://ksqldb-server:8088

https://docs.ksqldb.io/en/latest/tutorials/event-driven-microservice/?_ga=2.221453016.199770187.1705191424-292941759.1705191424

https://www.youtube.com/watch?v=4_o59tQNxeA

https://www.youtube.com/watch?v=gP8KxLCiiao
https://www.youtube.com/watch?v=URMwPPWOrVk

https://www.conduktor.io/kafka/how-to-start-kafka-using-docker/
https://github.com/conduktor/kafka-stack-docker-compose

https://www.kadeck.com
https://redpanda.com


https://gist.github.com/gschmutz/db582679c07c11f645b8cb9718e31209

