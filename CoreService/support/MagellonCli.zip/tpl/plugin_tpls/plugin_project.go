package plugin_tpls

import (
	"bytes"
	"encoding/json"
	"text/template"
)

type PluginType string

const (
	FFT                PluginType = "FFT"
	CTF                PluginType = "CTF"
	MotionCor          PluginType = "MotionCor"
	ParticlePicking    PluginType = "Particle Picking"
	TwoDClassification PluginType = "2D Classification"
	Other              PluginType = "Other"
)

var Options = []string{
	string(FFT),
	string(CTF),
	string(MotionCor),
	string(ParticlePicking),
	string(TwoDClassification),
	string(Other),
}

type Legal struct {
	Name            string   `json:"name"`
	PossibleMatches []string `json:"possibleMatches"`
	Text            string   `json:"text"`
	Header          string   `json:"header"`
}

type Item struct {
	Name        string `json:"name"`
	Type        string `json:"type"`
	IsOptional  bool   `json:"is_optional"`
	Description string `json:"description"`
}

type Project struct {
	Name         string     `json:"name"`
	Developer    string     `json:"developer"`
	Copyright    string     `json:"copyright"`
	AbsolutePath string     `json:"absolutePath"`
	Legal        Legal      `json:"legal"`
	EndpointName string     `json:"endpointName"`
	Items        []Item     `json:"items"`
	Type         PluginType `json:"type"`
}

func toJson(v interface{}) (string, error) {
	jsonBytes, err := json.Marshal(v)
	if err != nil {
		return "", err
	}
	return string(jsonBytes), nil
}

func GenerateInitContent(project Project) (string, error) {
	// Generate your init.json content here
	// Template content
	lastIndex := len(project.Items) - 1
	templateContent := `{
  "name": "{{ .Name }}",
  "type": "{{ .Type }}",
  "developer": "{{ .Developer }}",
  "copyright": "{{ .Copyright }}",
  "absolutePath": "{{ .AbsolutePath }}",
  "legal": {
    "name": "{{ .Legal.Name }}",
    "possibleMatches": {{ toJson .Legal.PossibleMatches }},
    "text": "{{ .Legal.Text }}",
    "header": "{{ .Legal.Header }}"
  },
  "endpointName": "{{ .EndpointName }}",
  "items": [
    {{ range $index, $item := .Items }}
    {
      "name": "{{ .Name }}",
      "type": "{{ .Type }}",
      "is_optional": {{ .IsOptional }},
      "description": "{{ .Description }}"
    }{{ if ne $index lastIndex }},{{ end }}
    {{ end }}
  ]
}`

	// Create a new template with the project data
	tmpl, err := template.New("json").Funcs(template.FuncMap{"toJson": toJson, "lastIndex": func() int { return lastIndex }}).Parse(templateContent)
	if err != nil {
		return "", err
	}

	// Use a bytes.Buffer as a writer to capture the template output
	var result bytes.Buffer

	// Execute the template with the project data
	err = tmpl.Execute(&result, project)
	if err != nil {
		return "", err
	}

	// Convert the buffer content to a string
	return result.String(), nil
}


